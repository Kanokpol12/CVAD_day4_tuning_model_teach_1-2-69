# ดึงฟังก์ชันที่เราเขียนไว้จากไฟล์ tuning_module.py มาใช้
from tuning_module import tune_yolo 

pretrained = "yolov8n.pt"  # ใช้โมเดลพื้นฐาน (ในสไลด์ระบุ yolo11n.pt แต่เราใช้ v8 ได้ครับ) [cite: 905]
data_yaml = "C:/Users/Bam/Desktop/IDEKTEP_ADV/CVAD2_teach/Train_cat_cvad2.v2i.yolov8/data.yaml"    # Path ไฟล์ตั้งค่าข้อมูลของเรา [cite: 909]
output_dir = "yolo_tuning_results" # ชื่อโฟลเดอร์ที่จะให้ผลลัพธ์ทั้งหมดไปรวมกัน [cite: 911]

# --- ตั้งค่าที่ต้องการนำมาทดสอบสลับกัน (Tuning Parameters) ---
img_sizes = [416, 640, 768 ,512 ]    # ลองขนาดภาพ 2 แบบ [cite: 918]
learning_rates = [0.01, 0.0005]  # ลองอัตราการเรียนรู้ 2 แบบ [cite: 920]
batch_sizes = [8 ,16 ,32]            # ลองจำนวน Batch 2 แบบ [cite: 923]
epochs = 150                 # จำนวนรอบ (ในสไลด์ทดสอบที่ 500 แต่เพื่อความรวดเร็วลองที่ 50 ก่อนได้ครับ) [cite: 925]
optimizer = "Adam"               # อัลกอริทึมที่ใช้ [cite: 928]

# สั่งให้ฟังก์ชันเริ่มทำงาน!
tune_yolo(pretrained, data_yaml, output_dir, img_sizes, learning_rates, batch_sizes, epochs, optimizer) 