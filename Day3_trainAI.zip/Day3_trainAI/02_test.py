from ultralytics import YOLO

# 1. โหลดไฟล์โมเดลที่ดีที่สุดจากการ Train ของเรา
# (อย่าลืมเปลี่ยน path ให้ชี้ไปที่โฟลเดอร์รันของคุณให้ถูกต้องนะครับ)
model = YOLO("C:/Users/Bam/Desktop/IDEKTEP_ADV/CVAD2_teach/runs/detect/yolo_tuning_results/run7_img640_lr0.0005_batch8/weights/best.pt") 

# 2. สั่งให้โมเดลทำนายรูปภาพ โดยกำหนดความมั่นใจขั้นต่ำที่ 10% (conf=0.1)
results = model("C:/Users/Bam/Desktop/IDEKTEP_ADV/CVAD2_teach/Train_cat_cvad2.v2i.yolov8/test/images/cat-10242_jpg.rf.43d6788b681e6a214866a6bcb0b749f6.jpg", conf=0.1)

# 3. แสดงรูปภาพผลลัพธ์พร้อมกรอบ Bounding Box
results[0].show()

# 4. แสดงรายละเอียดผลการตรวจจับออกมาเป็นตารางข้อมูล (DataFrame)
df = results[0].to_df()
print(df)

# 5. วนลูปตรวจสอบผลลัพธ์ที่ตรวจจับได้
for r in results:
    for box in r.boxes:
        # ดึงค่า ID ของคลาสที่ตรวจเจอ
        cls = int(box.cls[0])
        # แปลง ID เป็นชื่อคลาส
        name = model.names[cls]
        
        # ตรวจสอบว่าชื่อคลาสตรงกับที่เราต้องการหรือไม่ (เช่น "Face")
        if name == "cat":
            print("cat Found!")