from ultralytics import YOLO 

# โหลดโมเดลพื้นฐาน (Pretrained weight)
model = YOLO("yolov8n.pt") 

# เริ่มการ Train
model.train(
    data="C:/Users/Bam/Desktop/IDEKTEP_ADV/CVAD2/datasets/data.yaml", # ระบุ Path ไปยังไฟล์ data.yaml ให้ถูกต้อง [cite: 583]
    epochs=100,                   # จำนวนรอบในการ Train [cite: 587]
    imgsz=640,                   # ขนาดรูปภาพ [cite: 590]
    batch=16,                    # จำนวนรูปภาพต่อ 1 Batch [cite: 592]
    device='cpu',                    # ใส่ 0 ถ้าใช้การ์ดจอ Nvidia หรือใส่ 'cpu' ถ้าไม่มีการ์ดจอ [cite: 595, 596]
    name="yolov8_car_detector", # ชื่อโฟลเดอร์สำหรับบันทึกผลลัพธ์ [cite: 598]
    pretrained=True             # [cite: 602]
)